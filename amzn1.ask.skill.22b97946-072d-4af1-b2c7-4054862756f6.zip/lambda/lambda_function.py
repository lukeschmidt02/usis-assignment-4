# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


from pymongo import MongoClient
from time import time
from flask import Flask, request, jsonify
import json, datetime, random, certifi
import requests
import math
app = Flask(__name__)

class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Welcome to my final project. You can ask me about your health vitals or your environment. What would you like to know?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class HeartRateIntentHandler(AbstractRequestHandler):
    """Handler for Heart Rate Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HeartRateIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        hearturl  = "https://programming-assignment-three.herokuapp.com/heartrate/last"
        heartresp = requests.get(hearturl).json()
        heart_rate = heartresp['heart-rate']
        str_time_offset = heartresp['time-offset']
        
        speak_output = "Your heart rate, recorded {} minutes ago, is {} beats per minute.".format(str_time_offset,heart_rate)
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class StepCountIntentHandler(AbstractRequestHandler):
    """Handler for Step Count Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("StepCountIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        stepurl  = "https://programming-assignment-three.herokuapp.com/steps/last"
        stepresp = requests.get(stepurl).json()
        steps = stepresp['step-count']
        str_time_offset = stepresp['time-offset']
        
        speak_output = "Your step count, recorded {} minutes ago, is {}".format(str_time_offset,steps)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class SleepIntentHandler(AbstractRequestHandler):
    """Handler for Sleep Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("SleepIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        slots = handler_input.request_envelope.request.intent.slots
        today = 0
        try:
            date_slot = slots['DATE_SLOT']
            date = date_slot.value
            date = date[0:2] + "22" + date[4:]
        except:
            date = "today"
        
        time_slept_formatted = ""
        try:
            sleepurl  = "https://programming-assignment-three.herokuapp.com/sleep/" + date
            sleepresp = requests.get(sleepurl).json()

            deep = sleepresp['deep']
            light = sleepresp['light']
            rem = sleepresp['rem']
            total_sleep = deep + light + rem
            minutes = total_sleep
            hours = minutes // 60
            minutes = minutes % 60
            time_slept_formatted = "you slept for a total of {} hours and {} minutes".format(hours, minutes)
        except:
            time_slept_formatted = "no sleep data was recorded"

        date_formatted = "Last night"
        if (date != "today"):
            date_formatted = "On {}".format(date)

        speak_output = "{}, {}.".format(date_formatted, time_slept_formatted)
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class ActivityIntentHandler(AbstractRequestHandler):
    """Handler for Activity Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ActivityIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        slots = handler_input.request_envelope.request.intent.slots
        today = 0
        try:
            date_slot = slots['DATE_SLOT']
            date = date_slot.value
            date = date[0:2] + "22" + date[4:]
        except:
            date = "today"
            today = 1
        
        activityurl  = "https://programming-assignment-three.herokuapp.com/activity/" + date
        activityresp = requests.get(activityurl).json()
        
        lightly_active = activityresp['lightly-active']
        
        if (lightly_active >= 120):
            lightly_active = "{} hours and {}".format(math.floor(lightly_active/60),lightly_active % 60)
        elif (lightly_active >= 60):
            lightly_active = "{} hour and {}".format(math.floor(lightly_active/60),lightly_active % 60)
        
        
        sedentary = activityresp['sedentary']
        
        sedentary_hours = int(math.floor(sedentary/60))
        
        speak_output = "On {}, you had {} minutes of light activity. You were mostly sedentary for over {} hours".format(date,lightly_active,sedentary_hours)
        if (today == 1):
            speak_output = speak_output[3:]
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class EnvIntentHandler(AbstractRequestHandler):
    """Handler for Env Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("EnvIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        envurl  = "https://programming-assignment-three.herokuapp.com/sensors/env"
        envresp = requests.get(envurl).json()
        temp = envresp['temp']
        humidity = envresp['humidity']
        timestamp = envresp['timestamp']
        time_passed = time() - timestamp
        time_passed_formatted = int(math.floor(time_passed/60))
        passed_speak = ""
        if (time_passed < 60):
            passed_speak = "Right now"
        elif (time_passed_formatted == 1):
            passed_speak = "1 minute ago"
        elif (time_passed_formatted > 1):
            passed_speak = "{} minutes ago".format(time_passed_formatted)
        speak_output = "{}, the indoor temperature is {} degrees Fahrenheit with an {}% humidity.".format(passed_speak, temp, humidity)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class PoseIntentHandler(AbstractRequestHandler):
    """Handler for Pose Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("PoseIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        poseurl  = "https://programming-assignment-three.herokuapp.com/sensors/pose"
        poseresp = requests.get(poseurl).json()
        pose = poseresp['pose']
        timestamp = poseresp['timestamp']
        time_passed = timestamp - time()
        timestamp = poseresp['timestamp']
        time_passed = time() - timestamp
        time_passed_formatted = int(math.floor(time_passed/60))
        unit = ""
        if (int(time_passed) == 1):
            unit = 'second'
            time_passed_formatted = int(time_passed)
        elif (time_passed < 60):
            unit = 'seconds'
            time_passed_formatted = int(time_passed)
        elif (time_passed_formatted == 1):
            unit = "minute"
        elif (time_passed_formatted > 1):
            unit = "minutes"

        time_ago = "{} {}".format(time_passed_formatted, unit)
        
        speak_output = "You were seen {} {} ago".format(pose, time_ago)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CheckupBeginHandler(AbstractRequestHandler):
    """CheckupBegin"""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CheckupBeginIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        attr = handler_input.attributes_manager.session_attributes
        attr["game_node"] = 0
        
        speak_output = "How are you feeling today? You can say — I am fine, or I am tired, or I am in pain"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class FineHandler(AbstractRequestHandler):
    """Handler for fine Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("FineIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.session_attributes
        gstate = attr["game_node"]
        
        if gstate == 0:
            speak_output = "Glad to hear that! Take care!"
            gstate = -1
        else:
            speak_output = "Fine Invalid State {}. Lets try that again".format(gstate)
            gstate = -1
        
        
        attr["game_node"] = gstate

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class PainHandler(AbstractRequestHandler):
    """Handler for pain Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("PainIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.session_attributes
        gstate = attr["game_node"]
        
        if gstate == 0:
            speak_output = "You seem to have some sort of injury. Would you like me to call your caregiver?"
            gstate = 3
        else:
            speak_output = "Pain Invalid State {}. Lets try that again".format(gstate)
            gstate = -1
        
        
        attr["game_node"] = gstate

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class TiredHandler(AbstractRequestHandler):
    """Handler for tired Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("TiredIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.session_attributes
        gstate = attr["game_node"]
        
        if gstate == 0:
            speak_output = "Has your urine been very darkly colored?"
            gstate = 1
        else:
            speak_output = "Pain Invalid State {}. Lets try that again".format(gstate)
            gstate = -1
        
        attr["game_node"] = gstate

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class YesHandler(AbstractRequestHandler):
    """Handler for Yes Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.YesIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.session_attributes
        gstate = attr["game_node"]
        
        if gstate == 1:
            speak_output = "Have you noticed blood in the urine?"
            gstate = 2
        elif gstate == 2:
            speak_output = "You seem like you have a UTI, would you like me to call your caregiver?"
            gstate = 4
        elif gstate == 3:
            speak_output = "Calling Doctor Who"
            gstate = -1
        elif gstate == 4:
            speak_output = "Calling Doctor Who"
            gstate = -1
        elif gstate == 5:
            speak_output = "Calling Doctor Who"
            gstate = -1
        elif gstate == 6:
            speak_output = "Calling Doctor Who"
            gstate = -1
        else:
            speak_output = "Yes Invalid State {}. Lets try that again".format(gstate)
            gstate = -1            
        
        attr["game_node"] = gstate
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                 .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class NoHandler(AbstractRequestHandler):
    """Handler for No Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.NoIntent")(handler_input)
    
    
    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.session_attributes
        gstate = attr["game_node"]

        
        if gstate == 1:
            speak_output = "You seem fatigued, would you like me to call your caregiver?"
            gstate = 5
        elif gstate == 2:
            speak_output = "You seem dehydrated, would you like me to call your caregiver?"
            gstate = 6
        elif gstate == 3:
            speak_output = "Okay, here are some tips to properly treat an injury"
            gstate = -1
        elif gstate == 4:
            speak_output = "Okay, here are some tips for if you have a UTI"
            gstate = -1
        elif gstate == 5:
            speak_output = "Okay, Here are some tips about fatigue"
            gstate = -1
        elif gstate == 6:
            speak_output = "Okay, here are some tips about dehydration"
            gstate = -1
        else:
            speak_output = "No Invalid State {}. Lets try that again"
            gstate = -1            
        
        attr["game_node"] = gstate

        return (
            handler_input.response_builder
                .speak(speak_output)
                 .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You ask me about your health vitals or your environment. Even ask to perform your daily check-up. What would you like to know?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class FallbackIntentHandler(AbstractRequestHandler):
    """Single handler for Fallback Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        logger.info("In FallbackIntentHandler")
        speech = "Hmm, I'm not sure. You can say Hello or Help. What would you like to do?"
        reprompt = "I didn't catch that. What can I help you with?"

        return handler_input.response_builder.speak(speech).ask(reprompt).response

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HeartRateIntentHandler())
sb.add_request_handler(StepCountIntentHandler())
sb.add_request_handler(SleepIntentHandler())
sb.add_request_handler(ActivityIntentHandler())
sb.add_request_handler(EnvIntentHandler())
sb.add_request_handler(PoseIntentHandler())
sb.add_request_handler(CheckupBeginHandler())
sb.add_request_handler(FineHandler())
sb.add_request_handler(PainHandler())
sb.add_request_handler(TiredHandler())
sb.add_request_handler(YesHandler())
sb.add_request_handler(NoHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()